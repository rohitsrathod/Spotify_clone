## Spotify Clone
This project is a responsive clone of Spotify's web application built using only HTML and CSS.

 ## Features
- Responsive design that adapts to various screen sizes and devices.
- Replicates key features of the Spotify web player, such as the navigation bar, playlist layout, and player controls.
- Custom CSS styling without relying on external libraries.

## Technologies Used
- HTML
- CSS
